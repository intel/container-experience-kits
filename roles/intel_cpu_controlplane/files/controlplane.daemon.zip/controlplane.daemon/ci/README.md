# CI Installation

## Install Helm

## Install Tekton
- Follow the instructions on https://operatorhub.io/operator/tektoncd-operator
- curl -sL https://github.com/operator-framework/operator-lifecycle-manager/releases/download/v0.21.2/install.sh | bash -s v0.21.2
- kubectl apply -f requirements/tekton.yaml

## Install nginx and tekton dashboard:
- kubectl apply -f https://raw.githubusercontent.com/kubernetes/ingress-nginx/controller-v1.2.0/deploy/static/provider/baremetal/deploy.yaml
- kubectl apply -f requirements/tekton-dashboard-ingress.yaml

## Tekton pipiline creation/reinitilization
- Run reinstall-ci.sh

## Webhook
- Add a webhook to your ingress through github repo settings

# References
[^tekton]: https://tekton.dev/
[^tekton-operation]: https://github.com/tektoncd/operator/

