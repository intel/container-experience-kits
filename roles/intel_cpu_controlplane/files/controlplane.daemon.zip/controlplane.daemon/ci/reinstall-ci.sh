kubectl delete ns rm-ci-cd
kubectl delete pv controlplane-pv-volume
kubectl create namespace rm-ci-cd
helm template -f resourcemanagement.ci.tekton/values.yaml resourcemanagement.ci.tekton \
--set githubuser=$CI_GIT_USER --set githubtoken=$CI_GIT_TOKEN| kubectl apply -f-
