# Changelog
All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## 0.2 [22.06.2022]
### Added
- Add exclusive variant of numa-namespace policy. It makes guaranteed pods an exclusive access to cpus.
- Add cpu usage and auto-refresh to monitor
- Add support for Kind cluster for running integration tests
- Use klog logging
- Add support for containerd

## [Unreleased]