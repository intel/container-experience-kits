package agent

import (
	"context"
	"testing"
	"time"

	"github.com/go-logr/logr"
	"github.com/stretchr/testify/mock"
	"github.com/stretchr/testify/require"
	"google.golang.org/grpc"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"resourcemanagement.controlplane/pkg/ctlplaneapi"
)

type ControlPlaneClientMock struct {
	mock.Mock
}

func (c *ControlPlaneClientMock) CreatePod(
	ctx context.Context,
	in *ctlplaneapi.CreatePodRequest,
	opts ...grpc.CallOption,
) (*ctlplaneapi.PodAllocationReply, error) {
	args := c.Called(ctx, in)
	return args.Get(0).(*ctlplaneapi.PodAllocationReply), args.Error(1)
}

func (c *ControlPlaneClientMock) UpdatePod(
	ctx context.Context,
	in *ctlplaneapi.UpdatePodRequest,
	opts ...grpc.CallOption,
) (*ctlplaneapi.PodAllocationReply, error) {
	args := c.Called(ctx, in)
	return args.Get(0).(*ctlplaneapi.PodAllocationReply), args.Error(1)
}

func (c *ControlPlaneClientMock) DeletePod(
	ctx context.Context,
	in *ctlplaneapi.DeletePodRequest,
	opts ...grpc.CallOption,
) (*ctlplaneapi.PodAllocationReply, error) {
	args := c.Called(ctx, in)
	return args.Get(0).(*ctlplaneapi.PodAllocationReply), args.Error(1)
}

var _ ctlplaneapi.ControlPlaneClient = &ControlPlaneClientMock{}
var testCtx = logr.NewContext(context.TODO(), logr.Discard())

func TestCreatePodPasses(t *testing.T) {
	mock := ControlPlaneClientMock{}
	pod := genTestPod()
	podRequest, err := GetCreatePodRequest(&pod)
	require.Nil(t, err)
	mock.On("CreatePod", testCtx, podRequest).Return(&ctlplaneapi.PodAllocationReply{}, nil)
	agent := NewAgent(testCtx, &mock, "")

	agent.update(struct{}{}, &pod)

	mock.AssertExpectations(t)
}

func TestUpdateIgnoresDeletingPods(t *testing.T) {
	mock := ControlPlaneClientMock{}
	pod := genTestPod()
	pod.DeletionTimestamp = &metav1.Time{Time: time.Unix(0, 0)}
	agent := NewAgent(testCtx, &mock, "")

	agent.update(struct{}{}, &pod)

	mock.AssertExpectations(t)
}

func TestUpdateIgnoresNamespaceWithWrongPrefix(t *testing.T) {
	mock := ControlPlaneClientMock{}
	pod := genTestPod()
	agent := NewAgent(testCtx, &mock, "test")

	agent.update(struct{}{}, &pod)

	mock.AssertExpectations(t)
}

func TestUpdateIgnoresInitializingPods(t *testing.T) {
	mock := ControlPlaneClientMock{}
	pod := genTestPod()
	pod.Status.ContainerStatuses[0].Ready = false
	agent := NewAgent(testCtx, &mock, "")

	agent.update(struct{}{}, &pod)

	mock.AssertExpectations(t)
}

func TestUpdatePodPasses(t *testing.T) {
	mock := ControlPlaneClientMock{}
	pod := genTestPod()
	podCreateRequest, err := GetCreatePodRequest(&pod)
	require.Nil(t, err)
	podUpdateRequest, err := GetUpdatePodRequest(&pod)
	require.Nil(t, err)
	agent := NewAgent(testCtx, &mock, "")

	mock.On("CreatePod", testCtx, podCreateRequest).Return(&ctlplaneapi.PodAllocationReply{}, nil)
	agent.update(struct{}{}, &pod)
	mock.On("UpdatePod", testCtx, podUpdateRequest).Return(&ctlplaneapi.PodAllocationReply{}, nil)
	agent.update(struct{}{}, &pod)

	mock.AssertExpectations(t)
}

func TestDeletePodPasses(t *testing.T) {
	mock := ControlPlaneClientMock{}
	pod := genTestPod()
	podCreateRequest, err := GetCreatePodRequest(&pod)
	require.Nil(t, err)
	podDeleteRequest := GetDeletePodRequest(&pod)
	agent := NewAgent(testCtx, &mock, "")

	mock.On("CreatePod", testCtx, podCreateRequest).Return(&ctlplaneapi.PodAllocationReply{}, nil)
	agent.update(struct{}{}, &pod)
	mock.On("DeletePod", testCtx, podDeleteRequest).Return(&ctlplaneapi.PodAllocationReply{}, nil)
	agent.delete(&pod)

	mock.AssertExpectations(t)
}

func TestDeletePodIfNotAddedPreviously(t *testing.T) {
	mock := ControlPlaneClientMock{}
	pod := genTestPod()
	podDeleteRequest := GetDeletePodRequest(&pod)
	agent := NewAgent(testCtx, &mock, "")

	mock.On("DeletePod", testCtx, podDeleteRequest).Return(&ctlplaneapi.PodAllocationReply{}, nil)
	agent.delete(&pod)

	mock.AssertExpectations(t)
}

func TestDeleteIgnoresNamespaceWithWrongPrefix(t *testing.T) {
	mock := ControlPlaneClientMock{}
	pod := genTestPod()
	agent := NewAgent(testCtx, &mock, "test")

	agent.delete(&pod)

	mock.AssertExpectations(t)
}
