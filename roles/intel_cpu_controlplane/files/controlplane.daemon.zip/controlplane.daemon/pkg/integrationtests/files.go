//go:build integration
// +build integration

package integrationtests

import (
	"fmt"
	"io"
	"net"
	"net/http"
	"time"

	"resourcemanagement.controlplane/pkg/cpudaemon"
)

const (
	timeout = 2 * time.Second
)

func httpGet(url string) (*http.Response, error) {
	// TODO: Remove noProxyTransport after CI env is fixed
	var noProxyTransport http.RoundTripper = &http.Transport{
		Proxy: nil,
		DialContext: (&net.Dialer{
			Timeout:   10 * time.Second,
			KeepAlive: 30 * time.Second,
			DualStack: true,
		}).DialContext,
		MaxIdleConns:          30,
		IdleConnTimeout:       90 * time.Second,
		TLSHandshakeTimeout:   15 * time.Second,
		ExpectContinueTimeout: 1 * time.Second,
	}

	client := http.Client{
		Timeout:   timeout,
		Transport: noProxyTransport,
	}
	tlog.V(3).Info("sending http get", "url", url)
	return client.Get(url)
}

func remoteFileExists(node string, port int, path string) bool {
	url := fmt.Sprintf("http://%s:%d/%s", node, port, path)

	resp, err := httpGet(url)
	if err != nil {
		return false
	}
	return resp.StatusCode == http.StatusOK
}

func remoteFileGet(node string, port int, path string) (string, error) {
	url := fmt.Sprintf("http://%s:%d/%s", node, port, path)
	resp, err := httpGet(url)
	if err != nil {
		return "", err
	}
	if resp.StatusCode != http.StatusOK {
		return "", fmt.Errorf("status %d != %d", resp.StatusCode, http.StatusOK)
	}
	defer resp.Body.Close()
	data, err := io.ReadAll(resp.Body)
	if err != nil {
		return "", err
	}
	return string(data), nil
}

func loadDaemonStateFromWeb(addr string) (*cpudaemon.DaemonState, error) {
	resp, err := httpGet(addr)
	if err != nil {
		return nil, err
	}

	if resp.StatusCode != http.StatusOK {
		return nil, fmt.Errorf("server responded with status code %d", resp.StatusCode)
	}
	defer resp.Body.Close()
	state, err := cpudaemon.DaemonStateFromReader(resp.Body)
	return &state, err
}
