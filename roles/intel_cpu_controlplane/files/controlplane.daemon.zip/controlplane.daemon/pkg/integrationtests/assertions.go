//go:build integration
// +build integration

package integrationtests

import (
	"context"
	"encoding/json"
	"fmt"
	"net"
	"net/http"
	"net/url"
	"path"
	"sort"
	"testing"
	"time"

	"github.com/containerd/cgroups"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
	"resourcemanagement.controlplane/pkg/cpudaemon"
	"resourcemanagement.controlplane/pkg/ctlplaneapi"
	"resourcemanagement.controlplane/pkg/numautils"
)

func findCGroupPath(runtime cpudaemon.ContainerRuntime) (string, error) {
	cPath := "/sys/fs/cgroup/"
	if cgroups.Mode() != cgroups.Unified {
		cPath = "/sys/fs/cgroup/cpuset"
	}
	if runtime == cpudaemon.Kind {
		kindId, err := findKindDockerId()
		if err != nil {
			return "", err
		}

		return fmt.Sprintf(
			"%s/system.slice/docker-%s.scope/",
			cPath,
			kindId,
		), nil
	}
	return cPath, nil

}

func findKindDockerId() (string, error) {
	client := http.Client{
		Transport: &http.Transport{
			DialContext: func(_ context.Context, _, _ string) (net.Conn, error) {
				return net.Dial("unix", "/var/run/docker.sock")
			},
		},
		Timeout: time.Second,
	}
	response, err := client.Get(
		"http://dummy/containers/json?filters=" + url.QueryEscape("{\"name\": [\"/kind-control-plane\"]}"),
	)
	if err != nil {
		return "", err
	}
	if response.StatusCode != http.StatusOK {
		return "", fmt.Errorf("got response from docker daemon with status code %d", response.StatusCode)
	}
	defer response.Body.Close()

	var responseJson []map[string]any
	err = json.NewDecoder(response.Body).Decode(&responseJson)
	if err != nil {
		return "", err
	}
	if len(responseJson) != 1 {
		return "", fmt.Errorf("expected 1 container with name /kind-control-plane, got %d", len(responseJson))
	}

	kindId, ok := responseJson[0]["Id"]
	if !ok {
		return "", fmt.Errorf("No Id in response")
	}
	return kindId.(string), nil
}

func bucketToList(b []ctlplaneapi.CPUBucket) []int {
	result := []int{}
	for _, bucket := range b {
		for s := bucket.StartCPU; s <= bucket.EndCPU; s++ {
			result = append(result, s)
		}
	}
	sort.Ints(result)
	return result
}

// checkCPUSet checks if cpuset.cpus file has contents equal to `expectedState`. Returns error if
// contents are not the same, nil otherwise.
func checkCPUSet(
	namespace string,
	node string,
	fileServerPort int,
	cgroupPath string,
	container cpudaemon.Container,
	runtime cpudaemon.ContainerRuntime,
	cgroupDriver cpudaemon.CGroupDriver,
	expectedState []ctlplaneapi.CPUBucket,
) error {
	cpusetPath := path.Join(cgroupPath, cpudaemon.SliceName(container, runtime, cgroupDriver), "cpuset.cpus")
	content, err := remoteFileGet(node, fileServerPort, cpusetPath)
	if err != nil {
		return fmt.Errorf(
			"cannot get pinned cpus from http://%s:%d/%s, error: %s",
			node,
			fileServerPort,
			cpusetPath,
			err,
		)
	}

	buckets, err := cpudaemon.LoadCpuSetFromString(content)
	if err != nil {
		return fmt.Errorf("cannot read cpuset.cpus: %s", err)
	}

	daemonBuckets := bucketToList(expectedState)
	filesystemBuckets := bucketToList(buckets)
	if !assert.ObjectsAreEqual(daemonBuckets, filesystemBuckets) {
		return fmt.Errorf("cpu sets are different: filesystem %v daemon %v", filesystemBuckets, daemonBuckets)
	}
	return nil
}

// checkMemSet checks if cpuset.mems file is pinned to nodes from `usedCpus`. Returns error if
// contents are not the same, nil otherwise.
func checkMemSet(
	namespace string,
	node string,
	fileServerPort int,
	cgroupPath string,
	container cpudaemon.Container,
	runtime cpudaemon.ContainerRuntime,
	cgroupDriver cpudaemon.CGroupDriver,
	usedCpus []ctlplaneapi.CPUBucket,
	topology numautils.NumaTopology,
) error {
	cpusetPath := path.Join(cgroupPath, cpudaemon.SliceName(container, runtime, cgroupDriver), "cpuset.mems")
	content, err := remoteFileGet(node, fileServerPort, cpusetPath)
	if err != nil {
		return fmt.Errorf(
			"cannot get pinned mems from http://%s:%d/%s, error: %s",
			node,
			fileServerPort,
			cpusetPath,
			err,
		)
	}

	memBuckets, err := cpudaemon.CPUSetFromString(content)

	usedCpusSet := cpudaemon.CPUSetFromBucketList(usedCpus)
	expectedMemory := cpudaemon.CPUSet{}
	for cpu := range usedCpusSet {
		expectedMemory.Add(topology.CpuInformation[cpu].Node)
	}
	tlog.V(2).Info("Checking memory pinning", "expected", expectedMemory.Sorted(), "actual", memBuckets.Sorted())

	if !assert.ObjectsAreEqual(expectedMemory, memBuckets) {
		return fmt.Errorf("mem sets are different: filesystem %v daemon %v", memBuckets.Sorted(), expectedMemory.Sorted())
	}
	return nil
}

// retryAssertion retries `asserter` function `numTries` time until it returns true. If it fails, retryAssertion
// waits `backoffTime` duration until it tries again. If all attempts fail, it returns false and raises assertion.Fail.
func retryAssertion(t *testing.T, numTries int, backoffTime time.Duration, asserter func() error) bool {
	var err error
	for i := 0; i < numTries; i++ {
		err = asserter()
		if err == nil {
			return true
		}
		tlog.Error(err, "Retry assertion loop failed", "loop", i+1)
		time.Sleep(backoffTime)
	}
	assert.Fail(t, fmt.Sprintf("Assertion failed after %d tries. Last error %s", numTries, err.Error()))
	return false
}

// assertDaemonAndCGroup asserts if given deployment is visible in ctlplane daemon state. Then
// it asserts whether each pod cgroup cpuset.cpus content matches CPUs bound in the state file.
// This assertion is self-retrying.
func assertDaemonAndCGroup(suite *IntegrationTestSuite, info *deploymentInfo) {
	retryAssertion(suite.T(), retryCount, retryBackoff, func() error {
		for i, pod := range info.meta {
			state, err := loadDaemonStateFromWeb(getStateUrl(&info.pods.Items[i], suite.fileserverPort))
			if err != nil {
				return err
			}

			for _, container := range pod.containers {
				err := checkCPUSet(
					info.namespace,
					info.pods.Items[i].Status.HostIP,
					suite.fileserverPort,
					suite.cgroupPath,
					container,
					suite.containerRuntime,
					suite.cgroupDriver,
					state.Allocated[container.CID],
				)
				if err != nil {
					return err
				}
			}
		}
		return nil
	})
}

// assertDaemonAndMemory asserts if given deployment is visible in ctlplane daemon state. Then
// it asserts whether each pod cgroup cpuset.mems content matches CPUs nodes bound in the state file.
// This assertion is self-retrying.
func assertDaemonAndMemory(suite *IntegrationTestSuite, info *deploymentInfo) {
	retryAssertion(suite.T(), retryCount, retryBackoff, func() error {
		for i, pod := range info.meta {
			state, err := loadDaemonStateFromWeb(getStateUrl(&info.pods.Items[i], suite.fileserverPort))
			if err != nil {
				return err
			}

			for _, container := range pod.containers {
				err := checkMemSet(
					info.namespace,
					info.pods.Items[i].Status.HostIP,
					suite.fileserverPort,
					suite.cgroupPath,
					container,
					suite.containerRuntime,
					suite.cgroupDriver,
					state.Allocated[container.CID],
					state.Topology,
				)
				if err != nil {
					return err
				}
			}
		}
		return nil
	})
}

// assertDeploymentsInDaemonState asserts if all given deployments are added to ctlplane daemon state.
// This assertion is self-retrying.
func assertDeploymentsInDaemonState(suite *IntegrationTestSuite, infos []*deploymentInfo) {
	retryAssertion(suite.T(), retryCount, retryBackoff, func() error {
		for _, info := range infos {
			for i, pod := range info.meta {
				state, err := loadDaemonStateFromWeb(getStateUrl(&info.pods.Items[i], suite.fileserverPort))
				if err != nil {
					return err
				}

				for _, container := range pod.containers {
					if _, ok := state.Allocated[container.CID]; !ok {
						return fmt.Errorf("new container %s not visible in state", container.CID)
					}
				}
			}
		}
		return nil
	})
}

// assertDeploymentsNotInDaemonState asserts if all given deployments are not added to ctlplane daemon state.
func assertDeploymentsNotInDaemonState(suite *IntegrationTestSuite, infos []*deploymentInfo) {
	for _, info := range infos {
		for i, pod := range info.meta {
			state, err := loadDaemonStateFromWeb(getStateUrl(&info.pods.Items[i], suite.fileserverPort))
			require.Nil(suite.T(), err)

			for _, container := range pod.containers {
				assert.NotContains(suite.T(), state.Allocated, container.CID)
			}
		}
	}
}
