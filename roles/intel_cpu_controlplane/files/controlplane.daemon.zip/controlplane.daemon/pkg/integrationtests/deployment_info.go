//go:build integration
// +build integration

package integrationtests

import (
	appsv1 "k8s.io/api/apps/v1"
	apiv1 "k8s.io/api/core/v1"
	"k8s.io/client-go/kubernetes"
	appsclient "k8s.io/client-go/kubernetes/typed/apps/v1"
	"resourcemanagement.controlplane/pkg/cpudaemon"
)

type podMetaData struct {
	pid        string
	containers []cpudaemon.Container
}

type deploymentInfo struct {
	namespace  string
	deployment *appsv1.Deployment
	client     *appsclient.DeploymentInterface
	pods       *apiv1.PodList
	meta       []podMetaData
}

func newDeploymentInfo(namespace string, deployment *appsv1.Deployment, client *appsclient.DeploymentInterface) deploymentInfo {
	return deploymentInfo{
		namespace:  namespace,
		deployment: deployment,
		client:     client,
	}
}

// Waits until all pods of the deployment start
func (d *deploymentInfo) WaitUntilStarted(cl *kubernetes.Clientset) {
	tlog.V(2).Info("waiting for deployment to be ready", "deployment", d.deployment.Name, "namespace", d.namespace)
	podsMeta := []podMetaData{}
	podList := waitForAllPodsRunning(cl, d.deployment)

	for _, p := range podList.Items {
		containersPerPod := []cpudaemon.Container{}
		for i, c := range p.Status.ContainerStatuses {
			limCpu, _ := p.Spec.Containers[i].Resources.Limits.Cpu().AsInt64()
			reqCpu, _ := p.Spec.Containers[i].Resources.Requests.Cpu().AsInt64()
			qos := cpudaemon.QoSFromLimit(limCpu, reqCpu)
			containersPerPod = append(containersPerPod,
				cpudaemon.Container{
					CID:  c.ContainerID,
					PID:  string(p.GetUID()),
					Cpus: int(reqCpu),
					QS:   qos,
				},
			)
		}
		podsMeta = append(podsMeta, podMetaData{
			pid:        string(p.GetUID()),
			containers: containersPerPod,
		})
	}
	d.meta = podsMeta
	d.pods = podList
	tlog.V(2).Info("deployment ready", "deployment", d.deployment.Name, "namespace", d.namespace)
}

// Returns true if all pods of the deployment are deleted
func (d *deploymentInfo) IsDeleted(cl *kubernetes.Clientset) bool {
	podList := getPodList(cl, d.deployment)
	return len(podList.Items) == 0
}
