import os
import http.server
import socketserver

class Handler(http.server.SimpleHTTPRequestHandler):
    def do_GET(self):
        path = self.translate_path(self.path)
        if os.path.isdir(path):
            return super().do_GET()
        try:
            f = open(path, 'rb')
            data = f.read()

            self.send_response(http.server.HTTPStatus.OK)
            self.send_header("Content-type", "application/octet-stream")
            self.send_header("Content-Length", len(data))
            self.end_headers()

            self.wfile.write(data)
            self.wfile.flush()
        except OSError:
            self.send_error(http.server.HTTPStatus.NOT_FOUND, "File not found")
            return None
        finally:
            f.close()

with socketserver.TCPServer(("", 8000), Handler) as httpd:
    httpd.serve_forever()
