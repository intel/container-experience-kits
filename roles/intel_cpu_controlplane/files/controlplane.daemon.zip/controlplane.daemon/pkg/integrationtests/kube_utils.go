//go:build integration
// +build integration

package integrationtests

import (
	"context"
	_ "embed"
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"time"

	appsv1 "k8s.io/api/apps/v1"
	apiv1 "k8s.io/api/core/v1"
	v1 "k8s.io/api/core/v1"
	"k8s.io/apimachinery/pkg/api/resource"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/types"
	"k8s.io/apimachinery/pkg/util/intstr"
	"k8s.io/apimachinery/pkg/util/wait"
	"k8s.io/client-go/kubernetes"
	appsclient "k8s.io/client-go/kubernetes/typed/apps/v1"
	"k8s.io/client-go/rest"
	"k8s.io/client-go/tools/clientcmd"
	"k8s.io/client-go/util/homedir"
	"resourcemanagement.controlplane/pkg/cpudaemon"
)

const randStringLength = 5

// deleter is a function returned by resource creator, should be called to cleanup resources
type deleter func()

//go:embed data/fileserver.py
var fileServerCode string

func setupClient() (*kubernetes.Clientset, error) {
	var config *rest.Config

	config, err := rest.InClusterConfig()
	if err == rest.ErrNotInCluster {
		home := homedir.HomeDir()
		kubeconfig := filepath.Join(home, ".kube", "config")
		if _, err := os.Stat(kubeconfig); errors.Is(err, os.ErrNotExist) {
			return nil, fmt.Errorf("cannot load kube config, err: %s", err)
		}
		config, err = clientcmd.BuildConfigFromFlags("", kubeconfig)
		if err != nil {
			return nil, err
		}
	}
	clientset, err := kubernetes.NewForConfig(config)
	if err != nil {
		return nil, err
	}
	return clientset, nil
}

func createNamespace(cl *kubernetes.Clientset) (string, deleter, error) {
	namespace := "test-" + randString(randStringLength)
	nsObj := &v1.Namespace{
		ObjectMeta: metav1.ObjectMeta{
			Name: namespace,
		},
	}

	_, err := cl.CoreV1().Namespaces().Create(context.TODO(), nsObj, metav1.CreateOptions{})
	if err != nil {
		return "", nil, err
	}
	tlog.V(2).Info("created namespace", "ns", namespace)

	deleter := func() {
		tlog.V(2).Info("deleting namespace", "ns", namespace)
		cl.CoreV1().Namespaces().Delete(context.TODO(), namespace, metav1.DeleteOptions{})
	}
	return namespace, deleter, nil
}

func createNodePort(
	cl *kubernetes.Clientset,
	namespace string,
	selector map[string]string,
	servicePort, targetPort int,
) (int, deleter, error) {
	servicesClient := cl.CoreV1().Services(namespace)

	policy := v1.ServiceInternalTrafficPolicyLocal

	service := &apiv1.Service{
		ObjectMeta: metav1.ObjectMeta{
			Name: "test-node-port-" + randString(randStringLength),
		},
		Spec: apiv1.ServiceSpec{
			Type: v1.ServiceTypeNodePort,
			Ports: []v1.ServicePort{
				{
					Port:       int32(servicePort),
					TargetPort: intstr.FromInt(targetPort),
				},
			},
			Selector:              selector,
			ExternalTrafficPolicy: v1.ServiceExternalTrafficPolicyTypeLocal,
			InternalTrafficPolicy: &policy,
		},
	}

	result, err := servicesClient.Create(context.TODO(), service, metav1.CreateOptions{})
	if err != nil {
		return 0, nil, err
	}

	{
		selectorRepr := []string{}
		for k, v := range selector {
			selectorRepr = append(selectorRepr, k+"="+v)
		}
		tlog.V(2).Info(
			"created node port",
			"name",
			service.Name,
			"ns",
			namespace,
			"targetPort",
			targetPort,
			"selector",
			strings.Join(selectorRepr, ","),
		)
	}

	return int(
			result.Spec.Ports[0].NodePort,
		), func() {
			tlog.V(2).Info("deleting node port", "name", service.Name, "ns", namespace)
			servicesClient.Delete(context.TODO(), result.Name, metav1.DeleteOptions{})
		}, nil
}

func createConfigMap(cl *kubernetes.Clientset, namespace, name string, data map[string]string) (deleter, error) {
	confmapClient := cl.CoreV1().ConfigMaps(namespace)

	fileServerCMap := apiv1.ConfigMap{
		ObjectMeta: metav1.ObjectMeta{
			Name: name,
		},
		Data: data,
	}
	fileServerCodeInst, err := confmapClient.Create(context.TODO(), &fileServerCMap, metav1.CreateOptions{})
	if err != nil {
		return nil, err
	}
	tlog.V(2).Info("created configmap", "name", name, "ns", namespace)
	return func() {
		tlog.V(2).Info("deleting configmap", "name", name, "ns", namespace)
		confmapClient.Delete(context.TODO(), fileServerCodeInst.Name, metav1.DeleteOptions{})
	}, nil
}

func waitDaemonsetReady(cs *kubernetes.Clientset, namespace, name string, timeout time.Duration) error {
	if err := wait.Poll(500*time.Millisecond, timeout, func() (bool, error) {
		dsStat, err := cs.AppsV1().DaemonSets(namespace).Get(context.TODO(), name, metav1.GetOptions{})
		if err != nil {
			return false, nil
		}

		return dsStat.Status.NumberUnavailable == 0, nil
	}); err != nil {
		return fmt.Errorf("failed to wait for daemonset running %s/%s: %v", namespace, name, err)
	}
	return nil
}

func deleteDeployment(d *appsv1.Deployment, dInterface appsclient.DeploymentInterface) error {
	tlog.V(2).Info("deleting deployment", "name", d.Name, "ns", d.Namespace)
	deletePolicy := metav1.DeletePropagationForeground
	return dInterface.Delete(
		context.TODO(),
		d.Name,
		metav1.DeleteOptions{
			PropagationPolicy: &deletePolicy,
		},
	)
}

func deletePod(client *kubernetes.Clientset, namespace string, name string) error {
	tlog.V(2).Info("deleting pod", "name", name, "ns", namespace)
	return client.CoreV1().Pods(namespace).Delete(context.TODO(), name, metav1.DeleteOptions{})
}

// rsListFunc returns the ReplicaSet from the ReplicaSet namespace and the List metav1.ListOptions.
type rsListFunc func(string, metav1.ListOptions) ([]*appsv1.ReplicaSet, error)

// podListFunc returns the PodList from the Pod namespace and the List metav1.ListOptions.
type podListFunc func(string, metav1.ListOptions) (*v1.PodList, error)

// listReplicaSets returns a slice of RSes the given deployment targets.
// Note that this does NOT attempt to reconcile ControllerRef (adopt/orphan),
// because only the controller itself should do that.
// However, it does filter out anything whose ControllerRef doesn't match.
func listReplicaSets(deployment *appsv1.Deployment, getRSList rsListFunc) ([]*appsv1.ReplicaSet, error) {
	// TODO: Right now we list replica sets by their labels. We should list them by selector, i.e. the replica set's selector
	//       should be a superset of the deployment's selector, see https://github.com/kubernetes/kubernetes/issues/19830.
	namespace := deployment.Namespace
	selector, err := metav1.LabelSelectorAsSelector(deployment.Spec.Selector)
	if err != nil {
		return nil, err
	}
	options := metav1.ListOptions{LabelSelector: selector.String()}
	all, err := getRSList(namespace, options)
	if err != nil {
		return nil, err
	}
	// Only include those whose ControllerRef matches the Deployment.
	owned := make([]*appsv1.ReplicaSet, 0, len(all))
	for _, rs := range all {
		if metav1.IsControlledBy(rs, deployment) {
			owned = append(owned, rs)
		}
	}
	return owned, nil
}

// rsListFromClient returns an rsListFunc that wraps the given client.
func rsListFromClient(c appsclient.AppsV1Interface) rsListFunc {
	return func(namespace string, options metav1.ListOptions) ([]*appsv1.ReplicaSet, error) {
		rsList, err := c.ReplicaSets(namespace).List(context.TODO(), options)
		if err != nil {
			return nil, err
		}
		var ret []*appsv1.ReplicaSet
		for i := range rsList.Items {
			ret = append(ret, &rsList.Items[i])
		}
		return ret, err
	}
}

func listReplicaSetsFromDeployment(d *appsv1.Deployment, cl *kubernetes.Clientset) ([]*appsv1.ReplicaSet, error) {
	rsList, err := listReplicaSets(d, rsListFromClient(cl.AppsV1()))

	return rsList, err
}

// listPodsFromDeployment returns a list of pods the given deployment targets.
// This needs a list of ReplicaSets for the Deployment,
// which can be found with listReplicaSetsFromDeployment().
// Note that this does NOT attempt to reconcile ControllerRef (adopt/orphan),
// because only the controller itself should do that.
// However, it does filter out anything whose ControllerRef doesn't match.
func listPodsFromDeployment(
	deployment *appsv1.Deployment,
	rsList []*appsv1.ReplicaSet,
	getPodList podListFunc,
) (*v1.PodList, error) {
	namespace := deployment.Namespace
	selector, err := metav1.LabelSelectorAsSelector(deployment.Spec.Selector)
	if err != nil {
		return nil, err
	}
	options := metav1.ListOptions{LabelSelector: selector.String()}
	all, err := getPodList(namespace, options)
	if err != nil {
		return all, err
	}
	// Only include those whose ControllerRef points to a ReplicaSet that is in
	// turn owned by this Deployment.
	rsMap := make(map[types.UID]bool, len(rsList))
	for _, rs := range rsList {
		rsMap[rs.UID] = true
	}
	owned := &v1.PodList{Items: make([]v1.Pod, 0, len(all.Items))}
	for i := range all.Items {
		pod := &all.Items[i]
		controllerRef := metav1.GetControllerOf(pod)
		if controllerRef != nil && rsMap[controllerRef.UID] {
			owned.Items = append(owned.Items, *pod)
		}
	}
	return owned, nil
}

func waitForAllPodsRunning(
	cl *kubernetes.Clientset,
	deployment *appsv1.Deployment,
) *apiv1.PodList {
	var podList *apiv1.PodList
	for {
		podList = getPodList(cl, deployment)
		if len(podList.Items) == int(*deployment.Spec.Replicas) {
			allReady := true
			for _, p := range podList.Items {
				if p.Status.Phase != "Running" {
					allReady = false
					break
				}
			}
			if allReady {
				return podList
			}
		}
		time.Sleep(1 * time.Second)
	}
}

func getPodList(cl *kubernetes.Clientset, deployment *appsv1.Deployment) *apiv1.PodList {
	podListFunc := func(namespace string, options metav1.ListOptions) (*apiv1.PodList, error) {
		return cl.CoreV1().Pods(namespace).List(context.TODO(), options)
	}
	rs, err := listReplicaSetsFromDeployment(deployment, cl)
	if err != nil {
		panic(err)
	}
	podList, err := listPodsFromDeployment(deployment, rs, podListFunc)
	if err != nil {
		panic(err)
	}
	return podList
}

func createTestDeployment(cl *kubernetes.Clientset, namespace string, reqCpu, limCpu, replicas int, nodeName string) deploymentInfo {
	deploymentsClient := cl.AppsV1().Deployments(namespace)

	terminationPeriod := int64(0)
	replicasInt32 := int32(replicas)

	var resources apiv1.ResourceRequirements

	if reqCpu > 0 || limCpu > 0 {
		cpusRQ, err := resource.ParseQuantity(strconv.Itoa(reqCpu))
		if err != nil {
			panic(err)
		}
		cpusLQ, err := resource.ParseQuantity(strconv.Itoa(limCpu))
		if err != nil {
			panic(err)
		}
		memQ, err := resource.ParseQuantity("32Mi")
		if err != nil {
			panic(err)
		}
		resources = apiv1.ResourceRequirements{
			Requests: apiv1.ResourceList{
				apiv1.ResourceCPU:    cpusRQ,
				apiv1.ResourceMemory: memQ,
			},
			Limits: apiv1.ResourceList{
				apiv1.ResourceCPU:    cpusLQ,
				apiv1.ResourceMemory: memQ,
			},
		}
	}

	deployment := &appsv1.Deployment{
		ObjectMeta: metav1.ObjectMeta{
			Name: "ctlplane-test-deployment-" + randString(randStringLength),
		},
		Spec: appsv1.DeploymentSpec{
			Replicas: &replicasInt32,
			Selector: &metav1.LabelSelector{
				MatchLabels: map[string]string{
					"app": "demo",
				},
			},
			Template: apiv1.PodTemplateSpec{
				ObjectMeta: metav1.ObjectMeta{
					Labels: map[string]string{
						"app": "demo",
					},
				},
				Spec: apiv1.PodSpec{
					Containers: []apiv1.Container{
						{
							Name:      "spinner",
							Image:     "bash:4.4",
							Command:   []string{"bash", "-c", "sleep infinity"},
							Resources: resources,
						},
					},
					TerminationGracePeriodSeconds: &terminationPeriod,
					NodeName:                      nodeName,
				},
			},
		},
	}

	deployment, err := deploymentsClient.Create(context.TODO(), deployment, metav1.CreateOptions{})
	if err != nil {
		panic(err)
	}
	tlog.V(2).Info(
		"created deployment",
		"name",
		deployment.Name,
		"ns",
		namespace,
		"cpuReq",
		reqCpu,
		"cpuLim",
		limCpu,
		"replicas",
		replicas,
	)

	info := newDeploymentInfo(namespace, deployment, &deploymentsClient)
	info.WaitUntilStarted(cl)

	return info
}

func createFilesystemServer(cl *kubernetes.Clientset) (int, deleter, error) {
	failed := true
	runIfFailed := func(fn func()) {
		if failed {
			fn()
		}
	}

	confMapName := "python-sysfs-server-" + randString(randStringLength)
	confMapDeleter, err := createConfigMap(
		cl,
		"default",
		confMapName,
		map[string]string{
			"server.py": fileServerCode,
		},
	)
	if err != nil {
		return 0, nil, err
	}
	defer runIfFailed(confMapDeleter)

	dsName := "sysfs-file-server-" + randString(randStringLength)
	dsClient := cl.AppsV1().DaemonSets("default")
	fileServerDaemon := appsv1.DaemonSet{
		ObjectMeta: metav1.ObjectMeta{Name: dsName},
		Spec: appsv1.DaemonSetSpec{
			Selector: &metav1.LabelSelector{
				MatchLabels: map[string]string{
					"app": dsName,
				},
			},
			Template: v1.PodTemplateSpec{
				ObjectMeta: metav1.ObjectMeta{
					Labels: map[string]string{
						"app": dsName,
					},
				},
				Spec: v1.PodSpec{
					Containers: []v1.Container{
						{
							Name:       dsName,
							Image:      "python:3",
							Command:    []string{"python", "/srv/server.py"},
							WorkingDir: "/usr/share/data",
							Ports: []v1.ContainerPort{
								{
									ContainerPort: 8000,
								},
							},
							VolumeMounts: []v1.VolumeMount{
								{
									Name:      "host",
									MountPath: "/usr/share/data",
									ReadOnly:  true,
								},
								{
									Name:      "script",
									MountPath: "/srv/server.py",
									SubPath:   "server.py",
								},
							},
						},
					},
					Volumes: []v1.Volume{
						{
							Name: "host",
							VolumeSource: v1.VolumeSource{
								HostPath: &v1.HostPathVolumeSource{
									Path: "/",
								},
							},
						},
						{
							Name: "script",
							VolumeSource: v1.VolumeSource{
								ConfigMap: &v1.ConfigMapVolumeSource{
									LocalObjectReference: v1.LocalObjectReference{
										Name: confMapName,
									},
								},
							},
						},
					},
				},
			},
		},
	}
	daemonInstance, err := dsClient.Create(context.TODO(), &fileServerDaemon, metav1.CreateOptions{})

	tlog.V(2).Info("filesystem server created", "name", dsName, "ns", "default") // TODO: Create server in namespace
	if err != nil {
		return 0, nil, err
	}

	dsDeleter := func() {
		dsClient.Delete(context.TODO(), daemonInstance.Name, metav1.DeleteOptions{})
	}
	defer runIfFailed(dsDeleter)

	if err = waitDaemonsetReady(cl, daemonInstance.Namespace, daemonInstance.Name, 60*time.Second); err != nil {
		return 0, nil, err
	}
	tlog.V(2).Info("filesystem server ready")

	nodePort, nodePortDeleter, err := createNodePort(
		cl,
		"default",
		map[string]string{"app": dsName},
		8080,
		8000,
	)
	if err != nil {
		return 0, nil, err
	}

	failed = false

	return nodePort, func() {
		confMapDeleter()
		dsDeleter()
		nodePortDeleter()
	}, nil
}

func getAllDaemonSets(cl *kubernetes.Clientset) (*appsv1.DaemonSetList, error) {
	return cl.AppsV1().DaemonSets("").List(context.TODO(), metav1.ListOptions{})
}

func deriveRuntime(cl *kubernetes.Clientset) (cpudaemon.ContainerRuntime, error) {
	m, err := cl.CoreV1().Nodes().List(context.TODO(), metav1.ListOptions{
		LabelSelector: "node-role.kubernetes.io/master",
	})
	if err != nil {
		return 0, err
	}
	for _, n := range m.Items {
		if strings.HasPrefix(n.Spec.ProviderID, "kind") {
			return cpudaemon.Kind, nil
		}
		if strings.Contains(n.Status.NodeInfo.ContainerRuntimeVersion, "containerd") {
			return cpudaemon.ContainerdRunc, nil
		}
	}
	return cpudaemon.Docker, nil
}

func getCtlplaneParameters(daemonSet *appsv1.DaemonSet) (map[string]string, error) {
	containers := daemonSet.Spec.Template.Spec.Containers
	var container *v1.Container
	for _, cont := range containers {
		if cont.Name == "ctlplane-daemonset" {
			container = &cont
			break
		}
	}
	if container == nil {
		return map[string]string{}, fmt.Errorf("Container ctlplane-daemonset not present")
	}
	result := map[string]string{}
	var parameters []string
	finishParam := func() {
		if len(parameters) > 0 {
			result[parameters[0]] = strings.Join(parameters[1:], " ")
			parameters = []string{}
		}
	}
	for _, arg := range container.Args {
		if arg[0] == '-' {
			finishParam()
		}
		parameters = append(parameters, arg)
	}
	finishParam()
	return result, nil
}
