//go:build integration
// +build integration

package integrationtests

import (
	"flag"
	"fmt"
	"math/rand"
	"path"
	"testing"
	"time"

	"github.com/containerd/cgroups"
	"github.com/go-logr/logr"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
	"github.com/stretchr/testify/suite"
	appsv1 "k8s.io/api/apps/v1"
	v1 "k8s.io/api/core/v1"
	"k8s.io/klog/v2"
	"k8s.io/klog/v2/klogr"
	"resourcemanagement.controlplane/pkg/cpudaemon"

	"k8s.io/client-go/kubernetes"
)

const (
	retryCount   = 4
	retryBackoff = 3 * time.Second

	daemonWaitTimeout = 10 * time.Second
	daemonName        = "ctlplane-daemonset"
)

var tlog logr.Logger

type IntegrationTestSuite struct {
	suite.Suite

	client           *kubernetes.Clientset
	containerRuntime cpudaemon.ContainerRuntime
	cgroupDriver     cpudaemon.CGroupDriver
	parameters       map[string]string

	fileserverPort    int
	fileserverDeleter func()

	cgroupPath  string
	isCGroupsV2 bool
}

func (suite *IntegrationTestSuite) getParameter(key, defaultValue string) string {
	val, ok := suite.parameters[key]
	if ok {
		return val
	}
	return defaultValue
}

func (suite *IntegrationTestSuite) SetupSuite() {
	rand.Seed(time.Now().UnixNano())
	client, err := setupClient()
	require.Nil(suite.T(), err)
	require.NotNil(suite.T(), client)
	suite.client = client

	runtime, err := deriveRuntime(client)
	require.Nil(suite.T(), err)
	suite.containerRuntime = runtime
	suite.cgroupPath, err = findCGroupPath(runtime)
	suite.isCGroupsV2 = (cgroups.Mode() == cgroups.Unified)
	require.Nil(suite.T(), err)

	ctlPlaneDaemon := suite.waitUntilCtlPlaneDaemonSetIsReady()

	suite.parameters, err = getCtlplaneParameters(ctlPlaneDaemon)
	require.Nil(suite.T(), err)

	tlog.Info("environment ok", "runtime", runtime.String(), "cgroupPath", suite.cgroupPath, "parameters", suite.parameters)

	if suite.getParameter("-cgroup-driver", "") == "cgroupfs" {
		suite.cgroupDriver = cpudaemon.DriverCgroupfs
	} else {
		suite.cgroupDriver = cpudaemon.DriverSystemd
	}

	suite.fileserverPort, suite.fileserverDeleter, err = createFilesystemServer(suite.client)
	require.Nil(suite.T(), err, "cannot create filesystem server")
}

func (suite *IntegrationTestSuite) waitUntilCtlPlaneDaemonSetIsReady() *appsv1.DaemonSet {
	ctlPlaneDaemon, err := suite.getCtlPlaneDaemon()
	require.Nil(suite.T(), err, "ctlplane daemon is not running")
	ready := waitDaemonsetReady(suite.client, ctlPlaneDaemon.Namespace, daemonName, daemonWaitTimeout)
	if ready != nil {
		cond := []string{}
		for _, condition := range ctlPlaneDaemon.Status.Conditions {
			cond = append(cond, "Message: "+condition.Message+". Reason: "+condition.Reason)
		}
		if ready != nil {
			require.Fail(suite.T(), "Failed daemonset not ready.", "conditions %v", cond)
		}
	}
	return ctlPlaneDaemon
}

func (suite *IntegrationTestSuite) getCtlPlaneDaemon() (*appsv1.DaemonSet, error) {
	daemonSets, err := getAllDaemonSets(suite.client)
	if err != nil {
		return nil, fmt.Errorf("cannot retreive daemonsets, err: %s", err)
	}

	var ctlplaneDaemon *appsv1.DaemonSet
	for _, ds := range daemonSets.Items {
		if ds.Name == daemonName {
			ctlplaneDaemon = &ds
			break
		}
	}

	if ctlplaneDaemon == nil {
		return nil, fmt.Errorf("ctlplane-daemonset is not running")
	}
	return ctlplaneDaemon, nil
}

func (suite *IntegrationTestSuite) TearDownSuite() {
	suite.fileserverDeleter()
}

func getStateUrl(pod *v1.Pod, fileserverPort int) string {
	return fmt.Sprintf("http://%s:%d/usr/local/daemonstate/daemon.state", pod.Status.HostIP, fileserverPort)
}

// Sanity test, check if fileserver can serve files from cgroup folder
func (suite *IntegrationTestSuite) TestFileserverCanReadSysfs() {
	namespace, nsDeleter, err := createNamespace(suite.client)
	require.Nil(suite.T(), err, "cannot create namespace")
	defer nsDeleter()

	info := createTestDeployment(suite.client, namespace, 1, 1, 1, "")
	defer deleteDeployment(info.deployment, *info.client)

	retryAssertion(suite.T(), retryCount, retryBackoff, func() error {
		fileNameDependingOnCgroupV2 := map[bool]string{
			true:  "cpuset.cpus.effective",
			false: "cpuset.cpus",
		}
		cpus, err := remoteFileGet(
			info.pods.Items[0].Status.HostIP,
			suite.fileserverPort,
			path.Join(suite.cgroupPath, fileNameDependingOnCgroupV2[suite.isCGroupsV2]),
		)
		if err != nil {
			return err
		}
		_, err = cpudaemon.LoadCpuSetFromString(cpus)
		if err != nil {
			return fmt.Errorf("cannot parse cpuset: %s", err)
		}
		return nil
	})
}

// Checks if daemon pins cpus for guaranteed deployment
func (suite *IntegrationTestSuite) TestGuaranteedDeploymentHasCGroups() {
	namespace, nsDeleter, err := createNamespace(suite.client)
	require.Nil(suite.T(), err, "cannot create namespace")
	defer nsDeleter()

	info := createTestDeployment(suite.client, namespace, 3, 3, 2, "")
	defer deleteDeployment(info.deployment, *info.client)

	assertDaemonAndCGroup(suite, &info)
}

// Checks if daemon pins cpus for burstable deployment
func (suite *IntegrationTestSuite) TestBurstableDeploymentHasCGroups() {
	namespace, nsDeleter, err := createNamespace(suite.client)
	require.Nil(suite.T(), err, "cannot create namespace")
	defer nsDeleter()

	info := createTestDeployment(suite.client, namespace, 1, 2, 2, "")
	defer deleteDeployment(info.deployment, *info.client)

	assertDaemonAndCGroup(suite, &info)
}

// Checks if daemon pins cpus for best effort deployment
func (suite *IntegrationTestSuite) TestBestEffortDeploymentHasCGroups() {
	namespace, nsDeleter, err := createNamespace(suite.client)
	require.Nil(suite.T(), err, "cannot create namespace")
	defer nsDeleter()

	info := createTestDeployment(suite.client, namespace, 0, 0, 2, "")
	defer deleteDeployment(info.deployment, *info.client)

	assertDaemonAndCGroup(suite, &info)
}

// Checks if after deleting deployment, it is also deleted from the daemon state
func (suite *IntegrationTestSuite) TestDeploymentDeletedFromState() {
	namespace, nsDeleter, err := createNamespace(suite.client)
	require.Nil(suite.T(), err, "cannot create namespace")
	defer nsDeleter()

	info := createTestDeployment(suite.client, namespace, 1, 1, 1, "")
	deleteDeployment(info.deployment, *info.client)

	suite.waitUntilDeploymentDeleted(&info)
}

// Checks if daemon pins cpus for guaranteed deployment if it is in second namespace
func (suite *IntegrationTestSuite) TestGuaranteedDeploymentHasCGroupsIfOnSecondNamespace() {
	if suite.getParameter("-mem", "unk") == "unk" {
		suite.T().Skip("Test requires -mem option which is not set.")
	}
	namespace1, nsDeleter1, err := createNamespace(suite.client)
	require.Nil(suite.T(), err, "cannot create namespace")
	defer nsDeleter1()

	info1 := createTestDeployment(suite.client, namespace1, 3, 3, 2, "")
	defer deleteDeployment(info1.deployment, *info1.client)

	namespace2, nsDeleter2, err := createNamespace(suite.client)
	require.Nil(suite.T(), err, "cannot create namespace")
	defer nsDeleter2()

	info2 := createTestDeployment(suite.client, namespace2, 3, 3, 2, "")
	defer deleteDeployment(info2.deployment, *info2.client)

	assertDaemonAndMemory(suite, &info1)
	assertDaemonAndMemory(suite, &info2)
}

// Checks if after deleting pod and recreating it by deployment, it is replaced in daemon state
func (suite *IntegrationTestSuite) TestDeploymentPodReplaced() {
	namespace, nsDeleter, err := createNamespace(suite.client)
	require.Nil(suite.T(), err, "cannot create namespace")
	defer nsDeleter()

	info := createTestDeployment(suite.client, namespace, 1, 1, 2, "")
	defer deleteDeployment(info.deployment, *info.client)

	deletedPod := info.pods.Items[0]
	deletePod(suite.client, deletedPod.Namespace, deletedPod.Name)

	info.WaitUntilStarted(suite.client)

	retryAssertion(suite.T(), retryCount, retryBackoff, func() error {
		for i, pod := range info.meta {
			state, err := loadDaemonStateFromWeb(getStateUrl(&info.pods.Items[i], suite.fileserverPort))
			if err != nil {
				return err
			}

			if _, ok := state.Pods[pod.pid]; !ok {
				return fmt.Errorf("pod %s not in state", pod.pid)
			}
		}

		// now check if deleted pod is not visible in state
		state, err := loadDaemonStateFromWeb(getStateUrl(&deletedPod, suite.fileserverPort))
		if err != nil {
			return err
		}

		if _, ok := state.Pods[string(deletedPod.UID)]; ok {
			return fmt.Errorf("deleted pod %s still in state", deletedPod.UID)
		}

		return nil
	})
}

// [numa-namespace=2 only] Checks if after creating 2 namespaces, we can delete one of them and
// create 3rd one
func (suite *IntegrationTestSuite) TestNamespaceReplaced() {
	infos := []deploymentInfo{}
	nodeName := ""

	for i := 0; i < 2; i++ {
		namespace, nsDeleter, err := createNamespace(suite.client)
		require.Nil(suite.T(), err, "cannot create namespace")
		defer nsDeleter()
		info := createTestDeployment(suite.client, namespace, 1, 1, 1, nodeName)
		nodeName = info.pods.Items[0].Spec.NodeName // Allocate all deployments on the same node
		defer deleteDeployment(info.deployment, *info.client)
		infos = append(infos, info)
	}

	// delete 1st namespace
	deleteDeployment(infos[0].deployment, *infos[0].client)
	retryAssertion(suite.T(), retryCount, retryBackoff, func() error {
		if infos[0].IsDeleted(suite.client) {
			return nil
		} else {
			return fmt.Errorf("deployment not deleted")
		}
	})

	// create 3rd namespace
	namespace, nsDeleter, err := createNamespace(suite.client)
	require.Nil(suite.T(), err, "cannot create namespace")
	defer nsDeleter()
	info := createTestDeployment(suite.client, namespace, 1, 1, 1, nodeName)
	defer deleteDeployment(info.deployment, *info.client)

	assertDeploymentsInDaemonState(suite, []*deploymentInfo{&info})
}

// [numa-namespace=2 only] Checks if after creating 3 namespaces, the last one will be rejected
func (suite *IntegrationTestSuite) TestNamespaceRejected() {
	infos := []*deploymentInfo{}

	nodeName := ""
	for i := 0; i < 2; i++ {
		namespace, nsDeleter, err := createNamespace(suite.client)
		require.Nil(suite.T(), err, "cannot create namespace")
		defer nsDeleter()
		info := createTestDeployment(suite.client, namespace, 1, 1, 1, nodeName)
		nodeName = info.pods.Items[0].Spec.NodeName // Allocate all deployments on the same node
		defer deleteDeployment(info.deployment, *info.client)
		infos = append(infos, &info)
	}

	// check if deployments are added to the daemon
	assertDeploymentsInDaemonState(suite, infos)

	// create 3rd namespace
	namespace, nsDeleter, err := createNamespace(suite.client)
	require.Nil(suite.T(), err, "cannot create namespace")
	defer nsDeleter()
	info := createTestDeployment(suite.client, namespace, 1, 1, 1, nodeName)
	defer deleteDeployment(info.deployment, *info.client)

	// we need to sleep to make time for daemon to (not) allocate new namespace
	time.Sleep(retryBackoff * retryCount)

	assertDeploymentsNotInDaemonState(suite, []*deploymentInfo{&info})
}

// [numa-namespace-exclusive] Check if shared pool (burstable, besteffort) containers are updated after we add guaranteed pod
func (suite *IntegrationTestSuite) TestGuaranteedPodHasExclusiveCPU() {
	namespace, nsDeleter, err := createNamespace(suite.client)
	require.Nil(suite.T(), err, "cannot create namespace")
	defer nsDeleter()

	bestEffort := createTestDeployment(suite.client, namespace, 0, 0, 1, "")
	defer deleteDeployment(bestEffort.deployment, *bestEffort.client)
	nodeName := bestEffort.pods.Items[0].Spec.NodeName

	// best effort deployment took all cpus in bucket
	bestEffortOriginalCPUs, err := getAllocatedCPUs(suite, &bestEffort.pods.Items[0], bestEffort.meta[0].containers[0].CID)
	require.Nil(suite.T(), err)

	guaranteed := createTestDeployment(suite.client, namespace, 1, 1, 1, nodeName)
	defer deleteDeployment(guaranteed.deployment, *guaranteed.client)

	// guaranteed deployment took 1 exclusive cpu, deleting it from best effort container
	guaranteedCPUs, err := getAllocatedCPUs(suite, &guaranteed.pods.Items[0], guaranteed.meta[0].containers[0].CID)
	require.Nil(suite.T(), err)

	bestEffortNewCPUs, err := getAllocatedCPUs(suite, &bestEffort.pods.Items[0], bestEffort.meta[0].containers[0].CID)
	require.Nil(suite.T(), err)

	// now cpus should look like this:
	//   * bestEffortOriginalCPUs: [0, 1, 2, ...]
	//   * bestEffortNewCPUs: [1, 2, ...]
	//   * guaranteedCPUs: [0]
	// .Sorted() for nicer error output
	assert.Equal(suite.T(), guaranteedCPUs.Sorted(), bestEffortOriginalCPUs.RemoveAll(bestEffortNewCPUs).Sorted())
}

// [numa-namespace-exclusive] Check if shared pool (burstable, besteffort) containers are updated after we remove guaranteed pod
func (suite *IntegrationTestSuite) TestGuaranteedPodGivesBackExclusiveCPU() {
	namespace, nsDeleter, err := createNamespace(suite.client)
	require.Nil(suite.T(), err, "cannot create namespace")
	defer nsDeleter()

	guaranteed := createTestDeployment(suite.client, namespace, 1, 1, 1, "")
	defer deleteDeployment(guaranteed.deployment, *guaranteed.client)
	nodeName := guaranteed.pods.Items[0].Spec.NodeName

	// guaranteed deployment took 1 exclusive cpu
	guaranteedCPUs, err := getAllocatedCPUs(suite, &guaranteed.pods.Items[0], guaranteed.meta[0].containers[0].CID)
	require.Nil(suite.T(), err)

	bestEffort := createTestDeployment(suite.client, namespace, 0, 0, 1, nodeName)
	defer deleteDeployment(bestEffort.deployment, *bestEffort.client)

	// best effort deployment took all cpus in bucket except the one took by guaranteed
	bestEffortOriginalCPUs, err := getAllocatedCPUs(suite, &bestEffort.pods.Items[0], bestEffort.meta[0].containers[0].CID)
	require.Nil(suite.T(), err)

	// delete guaranteed deployment. it should return cpu to shared pool
	deleteDeployment(guaranteed.deployment, *guaranteed.client)
	require.True(suite.T(), suite.waitUntilDeploymentDeleted(&guaranteed))

	bestEffortNewCPUs, err := getAllocatedCPUs(suite, &bestEffort.pods.Items[0], bestEffort.meta[0].containers[0].CID)
	require.Nil(suite.T(), err)

	// now cpus should look like this:
	//   * bestEffortOriginalCPUs: [1, 2, ...]
	//   * bestEffortNewCPUs: [0, 1, 2, ...]
	//   * guaranteedCPUs: [0]
	// .Sorted() for nicer error output
	assert.Equal(suite.T(), guaranteedCPUs.Sorted(), bestEffortNewCPUs.RemoveAll(bestEffortOriginalCPUs).Sorted())
}

func TestIntegrationTestSuite(t *testing.T) {
	tlog = setupLogger()
	suite.Run(t, new(IntegrationTestSuite))
}

func (suite *IntegrationTestSuite) waitUntilDeploymentDeleted(info *deploymentInfo) bool {
	return retryAssertion(suite.T(), retryCount, retryBackoff, func() error {
		for i, pod := range info.meta {
			state, err := loadDaemonStateFromWeb(getStateUrl(&info.pods.Items[i], suite.fileserverPort))
			if err != nil {
				return err
			}
			for _, container := range pod.containers {
				if _, ok := state.Allocated[container.CID]; ok {
					return fmt.Errorf("container still visible in state")
				}
			}
		}
		return nil
	})
}

func getAllocatedCPUs(suite *IntegrationTestSuite, pod *v1.Pod, cid string) (cpudaemon.CPUSet, error) {
	var cpuSet cpudaemon.CPUSet
	done := retryAssertion(suite.T(), retryCount, retryBackoff, func() error {
		state, err := loadDaemonStateFromWeb(getStateUrl(pod, suite.fileserverPort))
		if err != nil {
			return err
		}

		if allocated, ok := state.Allocated[cid]; !ok {
			return fmt.Errorf("container %s not in state", cid)
		} else {
			cpuSet = cpudaemon.CPUSetFromBucketList(allocated)
		}
		return nil
	})
	if !done {
		return cpuSet, fmt.Errorf("cannot retreive allocated cpus")
	}
	return cpuSet, nil
}

func setupLogger() logr.Logger {
	flags := flag.NewFlagSet("klog", flag.ContinueOnError)
	klog.InitFlags(flags)
	_ = flags.Parse([]string{"-skip_headers", "true", "-v", "1"})
	return klogr.NewWithOptions(klogr.WithFormat(klogr.FormatKlog))
}
