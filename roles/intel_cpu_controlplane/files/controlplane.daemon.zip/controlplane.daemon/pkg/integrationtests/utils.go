//go:build integration
// +build integration

package integrationtests

import (
	"math/rand"
)

const alphabet = "abcdefghijklmnopqrstuvwxyz"

func randString(l int) string {
	result := make([]byte, l)
	for i := range result {
		result[i] = alphabet[rand.Intn(len(alphabet))]
	}
	return string(result)
}
