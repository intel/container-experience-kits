package numautils

import (
	"os"
	"path"
	"strconv"
	"strings"
)

// LinuxTopologyPath is a path where kernels exposes machine topology information.
const LinuxTopologyPath = "/sys/devices/system/node"

const (
	nodePrefix  = "node"
	cpuPrefix   = "cpu"
	topologyDir = "topology"
	packageFile = "package_id"
	dieFile     = "die_id"
	coreFile    = "core_id"
)

// CpuInfo stores topology information about single CPU.
type CpuInfo struct {
	Node    int
	Package int
	Die     int
	Core    int
	Cpu     int
}

func loadNodes(topologyPath string) ([]int, error) {
	return getEntriesWithPrefixAndNumber(topologyPath, nodePrefix)
}

func listCpusFromNode(topologyPath string, node int) ([]CpuInfo, error) {
	cpuIDs, err := getEntriesWithPrefixAndNumber(getNodeDirPath(topologyPath, node), cpuPrefix)
	if err != nil {
		return []CpuInfo{}, err
	}
	cpus := []CpuInfo{}
	for _, cpu := range cpuIDs {
		cpuTopologyBase := path.Join(getCPUDirPath(topologyPath, node, cpu), topologyDir)
		readOrDefault := func(file_name string) int {
			data, err := readIntFromFile(path.Join(cpuTopologyBase, file_name))
			if err != nil {
				return 0
			}
			return data
		}
		cpu := CpuInfo{
			Cpu:     cpu,
			Node:    node,
			Package: readOrDefault(packageFile),
			Die:     readOrDefault(dieFile),
			Core:    readOrDefault(coreFile),
		}
		cpus = append(cpus, cpu)
	}

	return cpus, nil
}

func getNodeDirPath(topologyPath string, node int) string {
	return path.Join(topologyPath, nodePrefix+strconv.Itoa(node))
}

func getCPUDirPath(topologyPath string, node int, cpu int) string {
	return path.Join(getNodeDirPath(topologyPath, node), cpuPrefix+strconv.Itoa(cpu))
}

func readIntFromFile(name string) (int, error) {
	data, err := os.ReadFile(name)
	if err != nil {
		return 0, err
	}
	return strconv.Atoi(strings.TrimSpace(string(data)))
}
