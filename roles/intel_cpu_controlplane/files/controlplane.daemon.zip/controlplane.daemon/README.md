# library.orchestrators.resourcemanagment.controlplane
Resource Management Control Plane for K8s

Requirements: 
* Ubuntu 20.04
* Docker: 20.10.14
* Containerd with systemd: 1.5.11 or newer 
* K8s 1.21.11 or newer

The Resource Management control plane is a k8s commponent which enables 
fine granular control of CPU resources in terms of pinning and cpu-pinning.
The component consists of two parts: a privileged daemonset responsible 
for control of the cgroups dependent for a given set of pods and containers. 

The current release supports Single NUMA and Namespace NUMA Isolation for 
guaranteed, best-effort and burstable containers. 

Installation:  

Build The controlplane container:
Use "make image" , this will create a docker image version 0.2

Push the image to preferred registry and change the registry path in manifest/ctlplane-daemon.yaml

The controlplane component requires admin privileges to function properply. 
Install admin priviliges for the default namespace by using the manifest/ctlplane-rbac.yaml
"kubectl apply -f manifest/ctlplane-daemon.yaml". This will start a daemon on all worker nodes.
The daemon will include 3 containers:

* Agent - Listens to Pod/Container CRUD events
* Daemon - Controls the CPU policies 

Enablement of Policies:
* The policies can be switched inside the ctlplane-daemon.yaml in the ctlplane-daemonset container section via : 

Example: 

args: ["-cpath", "/cgroup", "-spath", "/daemonstate/daemon.state", "-allocator", "numa-namespace=2"]

The allocator flag supports currently four policies:

* **default** this policy assings each guaranteed container to exclusive subset of cpus. Cpus are taken sequentially
(0, 1, 2, ...) from list of available cpus. Guaranteed and best-effort containers are not pinned.

* **numa** this policy assings each guaranteed container to exclusive subset of cpus with minimal topology distance.
Burstable and best-effort containers are not pinned.

* **numa-namespace:<number-of-namespaces>** this policy will isolate each namespace in separate NUMA zones.
It is required that the system supports a sufficient number of NUMA zones to assign separate zones to 
each namespace. Guaranteed container's cpus are shared with burstable and best-effort containers, but not
with other guaranteed containers.

* **numa-namespace-exclusive:<number-of-namespaces>** same as numa-namespace, except it assigns excusive cpus
to Guaranteed pods (they are not shared with burstable and best-effort containers)

Memory pinning:
* User can enable memory pinning when using NUMA-aware allocators. This can be done by invoking ctlplane daemon
with `-mem` option

CGroup driver:
* User can select which cgroup driver is used by the cluster. This can be done by invoking ctlplane daemon with `-cgroup-driver DRIVER` option, where `DRIVER` can be either `systemd` or `cgroupfs`. `systemd` is default option if not present.

Agent namespace filter:
* The agent can be configured to listen only to CRUD events inside namespaces with given prefix. This can
be configured inside ctlplane-daemon.yaml

Example:

args: ["-a", "-namespace-prefix", "test-"]
